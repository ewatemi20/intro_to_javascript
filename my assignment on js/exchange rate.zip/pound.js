alert("hello")
let naira =prompt("amount in naira");

function convertionpound() {
  let exchangeRate=0.00047302
  let pound =naira*exchangeRate
    return pound
}

alert(convertionpound())