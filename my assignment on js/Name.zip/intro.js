let first = prompt("What is your first name")

let last = prompt("What is your last name")

let age = prompt ("How old are you")

let output= first + ' ' + last + ' ' + age

 console.log(output)
 
 alert(output)