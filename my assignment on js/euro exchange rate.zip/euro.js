//convert naira to euro
alert("hello")
let naira =prompt("amount in naira");

function convertioneuro() {
  let exchangeRate=0.00056448
  let euro =naira*exchangeRate
    return euro 
}

alert(convertioneuro())
