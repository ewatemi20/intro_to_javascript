let Welcome=alert("welcome to my BMI calculator")
let name = prompt("What is your name")
let output= "welcome" + ' ' +name
alert(output)
let height =prompt("Get my height")
let weight =prompt("Get my weight")
let result=weight/1000*height**2
alert("Your BMI is" + ' ' +result+"kg")
console.log(result)
alert("Thank you for choosing me")